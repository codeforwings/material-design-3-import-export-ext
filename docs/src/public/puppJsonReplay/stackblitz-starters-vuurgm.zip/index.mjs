// run `node index.js` in the terminal
import { generatePuppeteerJSON } from './dist/generate-pupp-json.mjs';
import fs from 'node:fs';
// console.log(`Hello Node.js v${process.versions.node}!`);
export const sampleCoreColorsTheme = {
  primary: '#cba642',
  secondary: '#8b90a5',
  tertiary: '#7a93b0',
  neutral: '#837e76',
};
let tmp = generatePuppeteerJSON(sampleCoreColorsTheme);

console.log(tmp);
fs.writeFileSync('temp/import-colors.json', JSON.stringify(tmp, null, 2));
